using UnityEngine;

public class EnemigoSpawner : MonoBehaviour
{
    [SerializeField] private GameObject EnemigoPrefab;

    [SerializeField] private float spawnTime = 2f;
    [SerializeField] private float minLifeTime = 2f;
    [SerializeField] private float maxLifeTime = 5f;

    [SerializeField] private Vector3 spawnRange;

    private void Start()
    {
        InvokeRepeating(nameof(SpawnTarget), 1f, spawnTime);
    }

    private void SpawnTarget()
    {
        Vector3 randomPosition = new Vector3(
            Random.Range(-spawnRange.x, spawnRange.x),
            Random.Range(1f, spawnRange.y),
            Random.Range(-spawnRange.z, spawnRange.z)
        );

        GameObject target =
            Instantiate(EnemigoPrefab, randomPosition, Quaternion.identity);

        float lifeTime =
            Random.Range(minLifeTime, maxLifeTime);

        Destroy(target, lifeTime);
    }
}