using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    [SerializeField] private TextMeshProUGUI enemigosText;
    [SerializeField] private TextMeshProUGUI tiempoText;

    [SerializeField] private float startTime = 30f;
    [SerializeField] private float bonusTime = 2f;

    private int enemigosEliminados = 0;
    private float currentTime;

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        currentTime = startTime;
        ActualizarUI();
    }

    private void Update()
    {
        currentTime -= Time.deltaTime;

        tiempoText.text = "TIEMPO: " + Mathf.Ceil(currentTime);

        if (currentTime <= 0f)
        {
            ReiniciarJuego();
        }
    }

    public void AddScore()
    {
        enemigosEliminados++;
        currentTime += bonusTime;
        ActualizarUI();
    }

    private void ActualizarUI()
    {
        enemigosText.text = "ENEMIGOS: " + enemigosEliminados;
    }

    private void ReiniciarJuego()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}