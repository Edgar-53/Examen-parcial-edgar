using UnityEngine;

public class PlayerShooter : MonoBehaviour
{
    [SerializeField] private float shootDistance = 100f;

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Shoot();
        }
    }

    private void Shoot()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit, shootDistance))
        {
            if (hit.collider.CompareTag("Target"))
            {
                GameManager.Instance.AddScore();
                Destroy(hit.collider.gameObject);
            }
        }
    }
}